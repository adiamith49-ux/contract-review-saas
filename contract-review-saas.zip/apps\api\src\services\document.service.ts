import mammoth from "mammoth";
import pdf from "pdf-parse";

export async function extractText(file: { buffer: Buffer; mimeType: string; originalname: string }) {
  if (file.mimeType === "application/pdf" || file.originalname.toLowerCase().endsWith(".pdf")) {
    const parsed = await pdf(file.buffer);
    return parsed.text.trim();
  }

  if (
    file.mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    file.originalname.toLowerCase().endsWith(".docx")
  ) {
    const parsed = await mammoth.extractRawText({ buffer: file.buffer });
    return parsed.value.trim();
  }

  throw new Error("Unsupported file type. Upload PDF or DOCX.");
}
