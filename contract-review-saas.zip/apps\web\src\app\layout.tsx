import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CounselDesk",
  description: "AI contract review, redlining, and negotiation support"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
