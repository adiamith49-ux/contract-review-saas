import { Document, HeadingLevel, Packer, Paragraph, TextRun } from "docx";
import type { AnalysisPayload } from "../types.js";

export async function buildRedlineDocx(filename: string, analysis: Pick<AnalysisPayload, "redlines">) {
  const children = [
    new Paragraph({
      children: [new TextRun({ text: `Redline Suggestions: ${filename}`, bold: true, size: 28 })]
    }),
    new Paragraph({ text: "AI-generated insights are not legal advice." })
  ];

  for (const redline of analysis.redlines) {
    children.push(
      new Paragraph({ text: redline.clause, heading: HeadingLevel.HEADING_2 }),
      new Paragraph({ children: [new TextRun({ text: "Remove: ", bold: true }), new TextRun({ text: redline.original, strike: true, color: "B42318" })] }),
      new Paragraph({ children: [new TextRun({ text: "Add: ", bold: true }), new TextRun({ text: redline.proposed, color: "067647" })] }),
      new Paragraph({ children: [new TextRun({ text: "Reason: ", bold: true }), new TextRun(redline.reason)] }),
      new Paragraph({ children: [new TextRun({ text: "Fallback: ", bold: true }), new TextRun(redline.negotiationFallback)] })
    );
  }

  const doc = new Document({ sections: [{ children }] });
  return Packer.toBuffer(doc);
}
