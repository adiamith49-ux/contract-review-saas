import { Router } from "express";
import { query } from "../db.js";
import { requireAuth } from "../middleware/auth.js";

export const orgRouter = Router();

orgRouter.use(requireAuth);

orgRouter.get("/me", async (req, res, next) => {
  try {
    const org = await query("SELECT id, name, plan FROM organizations WHERE id = $1", [req.user?.orgId]);
    const activity = await query(
      "SELECT id, action, metadata, created_at FROM activity_logs WHERE org_id = $1 ORDER BY created_at DESC LIMIT 20",
      [req.user?.orgId]
    );

    return res.json({ user: req.user, organization: org.rows[0], activity: activity.rows });
  } catch (error) {
    return next(error);
  }
});
