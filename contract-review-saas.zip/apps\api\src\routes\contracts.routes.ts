import { Router } from "express";
import { createReadStream } from "node:fs";
import { access } from "node:fs/promises";
import multer from "multer";
import { z } from "zod";
import { constants as fsConstants } from "node:fs";
import { query } from "../db.js";
import { requireAuth } from "../middleware/auth.js";
import { analyzeContract } from "../services/ai.service.js";
import { logActivity } from "../services/activity.service.js";
import { extractText } from "../services/document.service.js";
import { buildRedlineDocx } from "../services/export.service.js";
import { assertWithinUsageLimits } from "../services/limits.service.js";
import { getContractSignedUrl, resolveLocalStoragePath, storeContractFile } from "../services/storage.service.js";
import type { AnalysisPayload, ContractType } from "../types.js";

const upload = multer({ storage: multer.memoryStorage() });
export const contractsRouter = Router();

const contractTypeSchema = z.enum(["nda", "msa", "saas", "sow", "order_form", "amendment", "employment", "vendor_agreement", "other"]);

contractsRouter.use(requireAuth);

contractsRouter.post("/upload-contract", upload.single("file"), async (req, res, next) => {
  try {
    if (!req.user || !req.file) {
      return res.status(400).json({ error: "Missing contract file" });
    }

    const contractType = contractTypeSchema.default("other").parse(req.body.type);
    await assertWithinUsageLimits(req.user.orgId, req.file.size);

    const extractedText = await extractText({
      buffer: req.file.buffer,
      mimeType: req.file.mimetype,
      originalname: req.file.originalname
    });
    const storageKey = await storeContractFile({
      buffer: req.file.buffer,
      mimeType: req.file.mimetype,
      orgId: req.user.orgId,
      filename: req.file.originalname
    });

    const created = await query<{ id: string }>(
      `INSERT INTO contracts (org_id, user_id, filename, storage_key, mime_type, file_size, type, status, extracted_text)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'uploaded', $8)
       RETURNING id`,
      [req.user.orgId, req.user.id, req.file.originalname, storageKey, req.file.mimetype, req.file.size, contractType, extractedText]
    );

    await query("INSERT INTO usage_events (org_id, user_id, contract_id, event_type) VALUES ($1, $2, $3, 'contract_uploaded')", [
      req.user.orgId,
      req.user.id,
      created.rows[0].id
    ]);
    await logActivity(req.user.orgId, req.user.id, "contract.uploaded", { contractId: created.rows[0].id });

    return res.status(201).json({ id: created.rows[0].id, status: "uploaded" });
  } catch (error) {
    return next(error);
  }
});

contractsRouter.get("/contracts", async (req, res, next) => {
  try {
    const result = await query(
      `SELECT c.id, c.filename, c.type, c.status, c.file_size, c.created_at, a.id AS analysis_id, a.risk_level
       FROM contracts c
       LEFT JOIN analyses a ON a.contract_id = c.id
       WHERE c.org_id = $1
       ORDER BY c.created_at DESC`,
      [req.user?.orgId]
    );
    return res.json({ contracts: result.rows });
  } catch (error) {
    return next(error);
  }
});

contractsRouter.get("/contracts/:id", async (req, res, next) => {
  try {
    const result = await query(
      `SELECT c.id, c.filename, c.type, c.status, c.file_size, c.mime_type, c.storage_key, c.created_at, a.id AS analysis_id, a.risk_level
       FROM contracts c
       LEFT JOIN analyses a ON a.contract_id = c.id
       WHERE c.id = $1 AND c.org_id = $2`,
      [req.params.id, req.user?.orgId]
    );
    const contract = result.rows[0];

    if (!contract) {
      return res.status(404).json({ error: "Contract not found" });
    }

    return res.json({ contract: { ...contract, signedUrl: await getContractSignedUrl(String(contract.storage_key)) } });
  } catch (error) {
    return next(error);
  }
});

contractsRouter.get("/files/:key(*)", async (req, res, next) => {
  try {
    const key = String(req.params.key ?? "");
    const contract = await query<{ mime_type: string; filename: string }>(
      "SELECT mime_type, filename FROM contracts WHERE storage_key = $1 AND org_id = $2",
      [key, req.user?.orgId]
    );

    if (!contract.rows[0]) {
      return res.status(404).json({ error: "File not found" });
    }

    const filePath = resolveLocalStoragePath(key);
    await access(filePath, fsConstants.R_OK);
    res.setHeader("Content-Type", contract.rows[0].mime_type);
    res.setHeader("Content-Disposition", `inline; filename="${contract.rows[0].filename}"`);
    return createReadStream(filePath).pipe(res);
  } catch (error) {
    return next(error);
  }
});

contractsRouter.post("/analyze", async (req, res, next) => {
  try {
    const { contractId } = z.object({ contractId: z.string().uuid() }).parse(req.body);
    const contract = await query<{ id: string; org_id: string; type: ContractType; extracted_text: string }>(
      "SELECT id, org_id, type, extracted_text FROM contracts WHERE id = $1 AND org_id = $2",
      [contractId, req.user?.orgId]
    );

    const row = contract.rows[0];
    if (!row) {
      return res.status(404).json({ error: "Contract not found" });
    }

    await query("UPDATE contracts SET status = 'processing', updated_at = now() WHERE id = $1", [contractId]);
    const analysis = await analyzeContract(row.extracted_text, row.type);

    const inserted = await query<{ id: string }>(
      `INSERT INTO analyses (contract_id, org_id, risk_level, risk_summary, clause_analysis, redlines, reasoning, negotiation_points, full_analysis, model)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       ON CONFLICT (contract_id) DO UPDATE SET
         risk_level = EXCLUDED.risk_level,
         risk_summary = EXCLUDED.risk_summary,
         clause_analysis = EXCLUDED.clause_analysis,
         redlines = EXCLUDED.redlines,
         reasoning = EXCLUDED.reasoning,
         negotiation_points = EXCLUDED.negotiation_points,
         full_analysis = EXCLUDED.full_analysis,
         model = EXCLUDED.model,
         created_at = now()
       RETURNING id`,
      [
        contractId,
        req.user?.orgId,
        analysis.riskLevel,
        JSON.stringify(analysis.riskSummary),
        JSON.stringify(analysis.clauseAnalysis),
        JSON.stringify(analysis.redlines),
        JSON.stringify(analysis.reasoning),
        JSON.stringify(analysis.negotiationPoints),
        JSON.stringify(analysis.fullAnalysis),
        analysis.model
      ]
    );

    await query("UPDATE contracts SET status = 'analyzed', updated_at = now() WHERE id = $1", [contractId]);
    await logActivity(req.user!.orgId, req.user!.id, "contract.analyzed", { contractId, analysisId: inserted.rows[0].id });
    return res.json({ analysisId: inserted.rows[0].id, status: "analyzed" });
  } catch (error) {
    if (req.body?.contractId) {
      await query("UPDATE contracts SET status = 'failed', error_message = $2, updated_at = now() WHERE id = $1", [
        req.body.contractId,
        error instanceof Error ? error.message : "Analysis failed"
      ]);
    }
    return next(error);
  }
});

contractsRouter.get("/analysis/:id", async (req, res, next) => {
  try {
    const result = await query(
      `SELECT a.*, c.filename, c.type
       FROM analyses a
       JOIN contracts c ON c.id = a.contract_id
       WHERE a.id = $1 AND a.org_id = $2`,
      [req.params.id, req.user?.orgId]
    );

    if (!result.rows[0]) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    return res.json({ analysis: result.rows[0] });
  } catch (error) {
    return next(error);
  }
});

contractsRouter.get("/analysis/:id/export.docx", async (req, res, next) => {
  try {
    const result = await query<{ filename: string; redlines: AnalysisPayload["redlines"] }>(
      `SELECT c.filename, a.redlines
       FROM analyses a
       JOIN contracts c ON c.id = a.contract_id
       WHERE a.id = $1 AND a.org_id = $2`,
      [req.params.id, req.user?.orgId]
    );

    if (!result.rows[0]) {
      return res.status(404).json({ error: "Analysis not found" });
    }

    const buffer = await buildRedlineDocx(result.rows[0].filename, { redlines: result.rows[0].redlines });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    res.setHeader("Content-Disposition", `attachment; filename="${result.rows[0].filename.replace(/\.[^.]+$/, "")}-redlines.docx"`);
    return res.send(buffer);
  } catch (error) {
    return next(error);
  }
});
