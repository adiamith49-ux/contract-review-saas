export type AuthUser = {
  id: string;
  orgId: string;
  email: string;
  role: "admin" | "member";
};

export type ContractType =
  | "nda"
  | "msa"
  | "saas"
  | "sow"
  | "order_form"
  | "amendment"
  | "employment"
  | "vendor_agreement"
  | "other";

export type AnalysisPayload = {
  riskLevel: "low" | "medium" | "high" | "critical";
  riskSummary: Array<{ area: string; risk: string; severity: string; recommendation: string }>;
  clauseAnalysis: Array<{ clause: string; finding: string; risk: string; recommendation: string }>;
  redlines: Array<{
    clause: string;
    original: string;
    proposed: string;
    reason: string;
    negotiationFallback: string;
  }>;
  reasoning: Array<{ change: string; rationale: string; businessImpact: string }>;
  negotiationPoints: Array<{ point: string; preferredPosition: string; fallbackPosition: string }>;
  fullAnalysis: Record<string, unknown>;
};

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}
