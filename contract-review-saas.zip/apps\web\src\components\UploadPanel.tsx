"use client";

import { Upload } from "lucide-react";
import { FormEvent, useState } from "react";
import { api } from "../lib/api";

const contractTypes = [
  ["nda", "NDA"],
  ["msa", "MSA"],
  ["saas", "SaaS"],
  ["sow", "SOW"],
  ["order_form", "Order Form"],
  ["amendment", "Amendment"],
  ["employment", "Employment"],
  ["vendor_agreement", "Vendor Agreement"],
  ["other", "Other"]
];

export function UploadPanel({ onUploaded }: { onUploaded: () => void }) {
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const form = new FormData(event.currentTarget);
      const uploaded = await api.uploadContract(form);
      await api.analyze(uploaded.id);
      setMessage("Analysis queued and completed for this MVP flow.");
      event.currentTarget.reset();
      onUploaded();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="panel">
      <div className="section-title">
        <div>
          <h2>Upload Contract</h2>
          <p className="muted">PDF and DOCX are supported.</p>
        </div>
        <Upload size={22} />
      </div>
      <form className="form" onSubmit={submit}>
        <label className="field">
          Contract type
          <select name="type" defaultValue="other">
            {contractTypes.map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          File
          <input name="file" type="file" accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required />
        </label>
        <button className="button primary" disabled={loading} type="submit">
          {loading ? "Analyzing..." : "Upload and analyze"}
        </button>
        {message && <p className="muted">{message}</p>}
      </form>
    </section>
  );
}
