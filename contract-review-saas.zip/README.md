# AI Contract Review SaaS

Production-oriented MVP for contract upload, AI risk analysis, redlining, negotiation support, subscriptions, and team access.

## Stack

- Frontend: Next.js, React, TypeScript
- Backend: Node.js, Express, TypeScript
- Database: PostgreSQL
- Storage: S3-compatible signed URLs
- AI: OpenAI Responses API
- Payments: Stripe subscriptions
- Deployment: Docker locally, Vercel frontend, AWS backend

## Run Locally

1. Create env files.

```powershell
Copy-Item apps\api\.env.example apps\api\.env
Copy-Item apps\web\.env.example apps\web\.env.local
```

2. Start PostgreSQL.

```powershell
docker compose up -d postgres
```

3. Install dependencies.

```powershell
npm install
```

4. Apply the schema.

```powershell
npm run db:migrate
```

5. Start the API and web app.

```powershell
npm run dev
```

Frontend: `http://localhost:3000`

API health: `http://localhost:4000/health`

## Local MVP Behavior

- Works without OpenAI: analysis falls back to a placeholder structured response.
- Works without Stripe: billing endpoints return a configuration message.
- Works without S3: files save under `apps/api/uploads` through the local storage adapter.
- Google OAuth is optional. Email and password auth works with the base setup.

## Notes

- The app includes the required disclaimer: AI-generated insights are not legal advice.
- Files are stored through an S3-compatible service interface with a built-in local fallback for development.
- Stripe price IDs are configured through environment variables.
- The OpenAI docs MCP could not be installed in this Codex session due local access denial, so the AI client is intentionally isolated in `apps/api/src/services/ai.service.ts` for easy model/API updates.
