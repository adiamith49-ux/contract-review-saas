import bcrypt from "bcryptjs";
import { OAuth2Client } from "google-auth-library";
import { Router } from "express";
import { z } from "zod";
import { config } from "../config.js";
import { query } from "../db.js";
import { signJwt } from "../middleware/auth.js";
import { logActivity } from "../services/activity.service.js";

export const authRouter = Router();

const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  organizationName: z.string().min(2)
});

authRouter.post("/signup", async (req, res, next) => {
  try {
    const input = signupSchema.parse(req.body);
    const passwordHash = await bcrypt.hash(input.password, 12);

    const result = await query<{ user_id: string; org_id: string }>(
      `WITH org AS (
        INSERT INTO organizations (name) VALUES ($1) RETURNING id
      ), new_user AS (
        INSERT INTO users (org_id, email, password_hash, role)
        SELECT org.id, $2, $3, 'admin' FROM org
        RETURNING id, org_id
      )
      SELECT id AS user_id, org_id FROM new_user`,
      [input.organizationName, input.email.toLowerCase(), passwordHash]
    );

    const user = { id: result.rows[0].user_id, orgId: result.rows[0].org_id, email: input.email.toLowerCase(), role: "admin" as const };
    await logActivity(user.orgId, user.id, "user.signup");
    res.status(201).json({ token: signJwt(user), user });
  } catch (error) {
    next(error);
  }
});

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });

authRouter.post("/login", async (req, res, next) => {
  try {
    const input = loginSchema.parse(req.body);
    const result = await query<{ id: string; org_id: string; email: string; role: "admin" | "member"; password_hash: string }>(
      "SELECT id, org_id, email, role, password_hash FROM users WHERE email = $1",
      [input.email.toLowerCase()]
    );
    const row = result.rows[0];

    if (!row?.password_hash || !(await bcrypt.compare(input.password, row.password_hash))) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const user = { id: row.id, orgId: row.org_id, email: row.email, role: row.role };
    await logActivity(user.orgId, user.id, "user.login");
    return res.json({ token: signJwt(user), user });
  } catch (error) {
    return next(error);
  }
});

authRouter.post("/google", async (req, res, next) => {
  try {
    if (!config.GOOGLE_CLIENT_ID) {
      return res.status(501).json({ error: "Google OAuth is not configured" });
    }

    const { credential } = z.object({ credential: z.string().min(1) }).parse(req.body);
    const client = new OAuth2Client(config.GOOGLE_CLIENT_ID);
    const ticket = await client.verifyIdToken({ idToken: credential, audience: config.GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();

    if (!payload?.email || !payload.sub) {
      return res.status(401).json({ error: "Invalid Google credential" });
    }

    const existing = await query<{ id: string; org_id: string; email: string; role: "admin" | "member" }>(
      "SELECT id, org_id, email, role FROM users WHERE email = $1 OR google_id = $2",
      [payload.email.toLowerCase(), payload.sub]
    );

    let user = existing.rows[0];
    if (!user) {
      const created = await query<{ user_id: string; org_id: string; email: string; role: "admin" }>(
        `WITH org AS (
          INSERT INTO organizations (name) VALUES ($1) RETURNING id
        ), new_user AS (
          INSERT INTO users (org_id, email, google_id, role)
          SELECT org.id, $2, $3, 'admin' FROM org
          RETURNING id, org_id, email, role
        )
        SELECT id AS user_id, org_id, email, role FROM new_user`,
        [payload.hd ?? "New Organization", payload.email.toLowerCase(), payload.sub]
      );
      user = { id: created.rows[0].user_id, org_id: created.rows[0].org_id, email: created.rows[0].email, role: created.rows[0].role };
    }

    const authUser = { id: user.id, orgId: user.org_id, email: user.email, role: user.role };
    await logActivity(authUser.orgId, authUser.id, "user.google_login");
    return res.json({ token: signJwt(authUser), user: authUser });
  } catch (error) {
    return next(error);
  }
});
