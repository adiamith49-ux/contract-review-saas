import OpenAI from "openai";
import { config } from "../config.js";
import type { AnalysisPayload, ContractType } from "../types.js";
import { buildContractPrompt, legalSystemPrompt } from "./prompts.js";

const openai = config.OPENAI_API_KEY ? new OpenAI({ apiKey: config.OPENAI_API_KEY }) : null;

const fallbackAnalysis: AnalysisPayload = {
  riskLevel: "medium",
  riskSummary: [
    {
      area: "General",
      risk: "OpenAI API key is not configured, so this is a placeholder analysis.",
      severity: "medium",
      recommendation: "Set OPENAI_API_KEY and re-run analysis."
    }
  ],
  clauseAnalysis: [],
  redlines: [],
  reasoning: [],
  negotiationPoints: [],
  fullAnalysis: {
    disclaimer: "AI-generated insights are not legal advice."
  }
};

export async function analyzeContract(text: string, contractType: ContractType): Promise<AnalysisPayload & { model: string }> {
  if (!openai) {
    return { ...fallbackAnalysis, model: "mock" };
  }

  const response = await openai.responses.create({
    model: config.OPENAI_MODEL,
    input: [
      { role: "system", content: legalSystemPrompt },
      { role: "user", content: buildContractPrompt(text, contractType) }
    ],
    text: {
      format: {
        type: "json_schema",
        name: "contract_analysis",
        schema: {
          type: "object",
          additionalProperties: false,
          required: ["riskLevel", "riskSummary", "clauseAnalysis", "redlines", "reasoning", "negotiationPoints", "fullAnalysis"],
          properties: {
            riskLevel: { type: "string", enum: ["low", "medium", "high", "critical"] },
            riskSummary: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                required: ["area", "risk", "severity", "recommendation"],
                properties: {
                  area: { type: "string" },
                  risk: { type: "string" },
                  severity: { type: "string" },
                  recommendation: { type: "string" }
                }
              }
            },
            clauseAnalysis: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                required: ["clause", "finding", "risk", "recommendation"],
                properties: {
                  clause: { type: "string" },
                  finding: { type: "string" },
                  risk: { type: "string" },
                  recommendation: { type: "string" }
                }
              }
            },
            redlines: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                required: ["clause", "original", "proposed", "reason", "negotiationFallback"],
                properties: {
                  clause: { type: "string" },
                  original: { type: "string" },
                  proposed: { type: "string" },
                  reason: { type: "string" },
                  negotiationFallback: { type: "string" }
                }
              }
            },
            reasoning: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                required: ["change", "rationale", "businessImpact"],
                properties: {
                  change: { type: "string" },
                  rationale: { type: "string" },
                  businessImpact: { type: "string" }
                }
              }
            },
            negotiationPoints: {
              type: "array",
              items: {
                type: "object",
                additionalProperties: false,
                required: ["point", "preferredPosition", "fallbackPosition"],
                properties: {
                  point: { type: "string" },
                  preferredPosition: { type: "string" },
                  fallbackPosition: { type: "string" }
                }
              }
            },
            fullAnalysis: { type: "object", additionalProperties: true }
          }
        },
        strict: true
      }
    }
  });

  return { ...(JSON.parse(response.output_text) as AnalysisPayload), model: config.OPENAI_MODEL };
}
