"use client";

import { Download, MessageSquareText, ShieldAlert, Sparkles } from "lucide-react";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { AppShell } from "../../../components/AppShell";
import { Analysis, API_URL, api, getToken } from "../../../lib/api";

const tabs = ["Risk Summary", "Redlines", "Negotiation Points", "Full Analysis"] as const;
type Tab = (typeof tabs)[number];

export default function AnalysisPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [tab, setTab] = useState<Tab>("Risk Summary");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!getToken()) {
      router.push("/login");
      return;
    }

    api
      .analysis(params.id)
      .then((result) => setAnalysis(result.analysis))
      .catch((err) => setError(err instanceof Error ? err.message : "Could not load analysis"));
  }, [params.id, router]);

  const exportUrl = useMemo(() => `${API_URL}/analysis/${params.id}/export.docx`, [params.id]);

  async function exportDocx() {
    const response = await fetch(exportUrl, {
      headers: { Authorization: `Bearer ${getToken()}` }
    });

    if (!response.ok) {
      setError("Could not export DOCX");
      return;
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${analysis?.filename?.replace(/\.[^.]+$/, "") ?? "contract"}-redlines.docx`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  return (
    <AppShell>
      <div className="section-title">
        <div>
          <h1>{analysis?.filename ?? "Analysis"}</h1>
          <p className="muted">
            {analysis?.type?.replace("_", " ")} | <span className={`badge ${analysis?.risk_level}`}>{analysis?.risk_level ?? "loading"}</span>
          </p>
        </div>
        <button className="button" onClick={() => void exportDocx()}>
          <Download size={16} /> Export DOCX
        </button>
      </div>
      <p className="disclaimer">AI-generated insights, not legal advice.</p>
      {error && <p className="muted">{error}</p>}
      <div className="tabs">
        {tabs.map((item) => (
          <button className={`tab ${tab === item ? "active" : ""}`} key={item} onClick={() => setTab(item)}>
            {item}
          </button>
        ))}
      </div>
      {!analysis ? (
        <section className="panel">Loading...</section>
      ) : (
        <>
          {tab === "Risk Summary" && (
            <section className="grid">
              {analysis.risk_summary.map((item) => (
                <article className="panel" key={`${item.area}-${item.risk}`}>
                  <div className="section-title">
                    <h2>{item.area}</h2>
                    <span className={`badge ${item.severity.toLowerCase()}`}>{item.severity}</span>
                  </div>
                  <p>{item.risk}</p>
                  <p className="muted">{item.recommendation}</p>
                </article>
              ))}
            </section>
          )}
          {tab === "Redlines" && (
            <section className="grid">
              {analysis.redlines.map((redline) => (
                <article className="panel redline" key={`${redline.clause}-${redline.original.slice(0, 20)}`}>
                  <div className="section-title">
                    <h2>{redline.clause}</h2>
                    <ShieldAlert size={20} />
                  </div>
                  <div className="diff remove">{redline.original}</div>
                  <div className="diff add">{redline.proposed}</div>
                  <p className="muted" title={redline.reason}>
                    Reason: {redline.reason}
                  </p>
                  <p className="muted">Fallback: {redline.negotiationFallback}</p>
                </article>
              ))}
              {analysis.redlines.length === 0 && <section className="panel">No redlines returned yet.</section>}
            </section>
          )}
          {tab === "Negotiation Points" && (
            <section className="grid">
              {analysis.negotiation_points.map((point) => (
                <article className="panel" key={point.point}>
                  <div className="section-title">
                    <h2>{point.point}</h2>
                    <MessageSquareText size={20} />
                  </div>
                  <p>{point.preferredPosition}</p>
                  <p className="muted">Fallback: {point.fallbackPosition}</p>
                </article>
              ))}
            </section>
          )}
          {tab === "Full Analysis" && (
            <section className="grid">
              <article className="panel">
                <div className="section-title">
                  <h2>Clause-by-Clause</h2>
                  <Sparkles size={20} />
                </div>
                <div className="stack">
                  {analysis.clause_analysis.map((clause) => (
                    <div key={`${clause.clause}-${clause.finding}`}>
                      <strong>{clause.clause}</strong>
                      <p>{clause.finding}</p>
                      <p className="muted">{clause.risk} | {clause.recommendation}</p>
                    </div>
                  ))}
                </div>
              </article>
              <article className="panel">
                <h2>Raw Structured Output</h2>
                <pre style={{ whiteSpace: "pre-wrap", overflowWrap: "anywhere" }}>{JSON.stringify(analysis.full_analysis, null, 2)}</pre>
              </article>
            </section>
          )}
        </>
      )}
    </AppShell>
  );
}
