"use client";

import { CreditCard } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AppShell } from "../../components/AppShell";
import { api, getToken } from "../../lib/api";

const plans = [
  { id: "free", name: "Free", price: "$0", detail: "3 contracts per month, 5MB files" },
  { id: "pro", name: "Pro", price: "$49", detail: "50 contracts per month, 25MB files" },
  { id: "team", name: "Team", price: "$199", detail: "250 contracts per month, team access, 50MB files" }
] as const;

export default function BillingPage() {
  const router = useRouter();
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!getToken()) {
      router.push("/login");
    }
  }, [router]);

  async function upgrade(plan: "pro" | "team") {
    try {
      setMessage("");
      const result = await api.checkout(plan);
      window.location.href = result.url;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not start checkout");
    }
  }

  return (
    <AppShell>
      <div className="section-title">
        <div>
          <h1>Billing</h1>
          <p className="muted">Subscription billing is powered by Stripe.</p>
        </div>
        <CreditCard size={22} />
      </div>
      {message && <p className="muted">{message}</p>}
      <section className="grid">
        {plans.map((plan) => (
          <article className="panel" key={plan.id}>
            <div className="section-title">
              <div>
                <h2>{plan.name}</h2>
                <p className="muted">{plan.detail}</p>
              </div>
              <strong>{plan.price}</strong>
            </div>
            {plan.id === "free" ? (
              <span className="badge low">Included</span>
            ) : (
              <button className="button primary" onClick={() => void upgrade(plan.id)}>
                Upgrade
              </button>
            )}
          </article>
        ))}
      </section>
    </AppShell>
  );
}
