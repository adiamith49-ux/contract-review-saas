const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000/api";

export type ContractListItem = {
  id: string;
  filename: string;
  type: string;
  status: string;
  file_size: number;
  created_at: string;
  analysis_id?: string;
  risk_level?: string;
};

export type Analysis = {
  id: string;
  contract_id: string;
  filename: string;
  type: string;
  risk_level: string;
  risk_summary: Array<{ area: string; risk: string; severity: string; recommendation: string }>;
  clause_analysis: Array<{ clause: string; finding: string; risk: string; recommendation: string }>;
  redlines: Array<{ clause: string; original: string; proposed: string; reason: string; negotiationFallback: string }>;
  reasoning: Array<{ change: string; rationale: string; businessImpact: string }>;
  negotiation_points: Array<{ point: string; preferredPosition: string; fallbackPosition: string }>;
  full_analysis: Record<string, unknown>;
};

export function getToken() {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("token");
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (!(options.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  if (!response.ok) {
    const payload = await response.json().catch(() => ({ error: response.statusText }));
    throw new Error(payload.error ?? "Request failed");
  }
  return response.json();
}

export const api = {
  signup: (body: { email: string; password: string; organizationName: string }) =>
    request<{ token: string; user: { email: string } }>("/auth/signup", { method: "POST", body: JSON.stringify(body) }),
  login: (body: { email: string; password: string }) =>
    request<{ token: string; user: { email: string } }>("/auth/login", { method: "POST", body: JSON.stringify(body) }),
  me: () => request<{ user: unknown; organization: { name: string; plan: string }; activity: Array<{ id: string; action: string; created_at: string }> }>("/me"),
  contracts: () => request<{ contracts: ContractListItem[] }>("/contracts"),
  uploadContract: (formData: FormData) => request<{ id: string; status: string }>("/upload-contract", { method: "POST", body: formData }),
  analyze: (contractId: string) => request<{ analysisId: string; status: string }>("/analyze", { method: "POST", body: JSON.stringify({ contractId }) }),
  analysis: (id: string) => request<{ analysis: Analysis }>(`/analysis/${id}`),
  checkout: (plan: "pro" | "team") => request<{ url: string }>("/billing/checkout", { method: "POST", body: JSON.stringify({ plan }) })
};

export { API_URL };
