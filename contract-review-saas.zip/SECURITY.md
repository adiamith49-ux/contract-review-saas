# Security Notes

- Store original contracts in S3 with server-side encryption enabled.
- Serve files through short-lived signed URLs only.
- JWT secrets, OpenAI keys, Stripe keys, and S3 credentials must stay in environment variables.
- The app does not send contract text to model training workflows. OpenAI usage is isolated in `apps/api/src/services/ai.service.ts`.
- Displayed analysis includes the required disclaimer: AI-generated insights are not legal advice.
- Add vendor DPAs, audit logging retention, malware scanning, and per-tenant encryption keys before handling regulated production workloads.
