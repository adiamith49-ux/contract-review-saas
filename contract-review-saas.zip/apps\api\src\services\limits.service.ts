import { query } from "../db.js";

const planLimits = {
  free: { contractsPerMonth: 3, maxFileMb: 5 },
  pro: { contractsPerMonth: 50, maxFileMb: 25 },
  team: { contractsPerMonth: 250, maxFileMb: 50 }
} as const;

export async function assertWithinUsageLimits(orgId: string, fileSizeBytes: number) {
  const org = await query<{ plan: keyof typeof planLimits }>("SELECT plan FROM organizations WHERE id = $1", [orgId]);
  const plan = org.rows[0]?.plan ?? "free";
  const limits = planLimits[plan];

  if (fileSizeBytes > limits.maxFileMb * 1024 * 1024) {
    throw new Error(`File exceeds ${limits.maxFileMb}MB limit for ${plan} plan`);
  }

  const usage = await query<{ count: string }>(
    "SELECT count(*) FROM usage_events WHERE org_id = $1 AND event_type = 'contract_uploaded' AND created_at >= date_trunc('month', now())",
    [orgId]
  );

  if (Number(usage.rows[0]?.count ?? 0) >= limits.contractsPerMonth) {
    throw new Error(`Monthly contract limit reached for ${plan} plan`);
  }
}
