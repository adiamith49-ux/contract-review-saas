import type { ContractType } from "../types.js";

export const legalSystemPrompt = [
  "You are a senior corporate lawyer specializing in commercial contracts.",
  "Provide precise, business-focused legal analysis.",
  "Flag legal and business risk, but do not claim to provide legal advice.",
  "Return only valid JSON matching the requested schema."
].join(" ");

export function buildContractPrompt(contractText: string, contractType: ContractType) {
  return `
Analyze this ${contractType} contract.

Output:
- Risk summary across liability, indemnity, payment terms, termination, data protection, confidentiality, IP, governing law, assignment, audit, SLA, and remedies where applicable.
- Unfavorable clauses.
- Missing protections.
- Clause-by-clause analysis.
- Redline suggestions using original/proposed text pairs.
- Reasoning for each suggested change.
- Negotiation strategy with fallback positions.

Contract:
${contractText.slice(0, 120000)}
`;
}
