import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { PutObjectCommand, S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { config } from "../config.js";

const s3 = new S3Client({
  region: config.AWS_REGION,
  endpoint: config.S3_ENDPOINT || undefined,
  forcePathStyle: Boolean(config.S3_ENDPOINT),
  credentials:
    config.S3_ACCESS_KEY_ID && config.S3_SECRET_ACCESS_KEY
      ? { accessKeyId: config.S3_ACCESS_KEY_ID, secretAccessKey: config.S3_SECRET_ACCESS_KEY }
      : undefined
});

export async function storeContractFile(input: { buffer: Buffer; mimeType: string; orgId: string; filename: string }) {
  const safeName = input.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
  const key = `orgs/${input.orgId}/contracts/${crypto.randomUUID()}-${safeName}`;

  if (config.STORAGE_DRIVER === "local") {
    const filePath = resolve(process.cwd(), config.LOCAL_UPLOAD_DIR, key);
    await mkdir(dirname(filePath), { recursive: true });
    await writeFile(filePath, input.buffer);
    return key;
  }

  if (!config.S3_BUCKET) {
    throw new Error("S3_BUCKET is required when STORAGE_DRIVER=s3");
  }

  await s3.send(
    new PutObjectCommand({
      Bucket: config.S3_BUCKET,
      Key: key,
      Body: input.buffer,
      ContentType: input.mimeType,
      ServerSideEncryption: "AES256"
    })
  );

  return key;
}

export async function getContractSignedUrl(key: string) {
  if (config.STORAGE_DRIVER === "local") {
    return `${config.API_BASE_URL}/api/files/${encodeURIComponent(key)}`;
  }

  if (!config.S3_BUCKET) {
    throw new Error("S3_BUCKET is required when STORAGE_DRIVER=s3");
  }

  return getSignedUrl(s3, new GetObjectCommand({ Bucket: config.S3_BUCKET, Key: key }), { expiresIn: 900 });
}

export function resolveLocalStoragePath(key: string) {
  return resolve(process.cwd(), config.LOCAL_UPLOAD_DIR, key);
}
