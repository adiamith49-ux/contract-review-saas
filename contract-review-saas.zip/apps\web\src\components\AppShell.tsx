"use client";

import { FileText, LayoutDashboard, LogOut, ReceiptText } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();

  function logout() {
    window.localStorage.removeItem("token");
    router.push("/login");
  }

  return (
    <div className="shell">
      <header className="topbar">
        <Link className="brand" href="/">
          <span className="brand-mark">
            <FileText size={18} />
          </span>
          CounselDesk
        </Link>
        <nav className="nav">
          <Link href="/">
            <LayoutDashboard size={16} /> Dashboard
          </Link>
          <Link href="/billing">
            <ReceiptText size={16} /> Billing
          </Link>
          <button className="icon-button" aria-label="Log out" title="Log out" onClick={logout}>
            <LogOut size={18} />
          </button>
        </nav>
      </header>
      <main className="main">{children}</main>
    </div>
  );
}
