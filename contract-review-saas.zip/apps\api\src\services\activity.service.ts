import { query } from "../db.js";

export async function logActivity(orgId: string, userId: string | null, action: string, metadata: Record<string, unknown> = {}) {
  await query(
    "INSERT INTO activity_logs (org_id, user_id, action, metadata) VALUES ($1, $2, $3, $4)",
    [orgId, userId, action, metadata]
  );
}
