CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE org_plan AS ENUM ('free', 'pro', 'team');
CREATE TYPE org_role AS ENUM ('admin', 'member');
CREATE TYPE contract_status AS ENUM ('uploaded', 'processing', 'analyzed', 'failed');
CREATE TYPE contract_type AS ENUM ('nda', 'msa', 'saas', 'sow', 'order_form', 'amendment', 'employment', 'vendor_agreement', 'other');
CREATE TYPE risk_level AS ENUM ('low', 'medium', 'high', 'critical');

CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  plan org_plan NOT NULL DEFAULT 'free',
  stripe_customer_id text,
  stripe_subscription_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email text NOT NULL UNIQUE,
  password_hash text,
  google_id text UNIQUE,
  role org_role NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE contracts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  filename text NOT NULL,
  storage_key text NOT NULL,
  file_url text,
  mime_type text NOT NULL,
  file_size bigint NOT NULL,
  type contract_type NOT NULL DEFAULT 'other',
  status contract_status NOT NULL DEFAULT 'uploaded',
  extracted_text text,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contract_id uuid NOT NULL UNIQUE REFERENCES contracts(id) ON DELETE CASCADE,
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  risk_level risk_level NOT NULL,
  risk_summary jsonb NOT NULL,
  clause_analysis jsonb NOT NULL,
  redlines jsonb NOT NULL,
  reasoning jsonb NOT NULL,
  negotiation_points jsonb NOT NULL,
  full_analysis jsonb NOT NULL,
  model text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE usage_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  contract_id uuid REFERENCES contracts(id) ON DELETE SET NULL,
  event_type text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_contracts_org_created ON contracts(org_id, created_at DESC);
CREATE INDEX idx_analyses_org_created ON analyses(org_id, created_at DESC);
CREATE INDEX idx_usage_events_month ON usage_events(org_id, created_at);
