"use client";

import { Scale } from "lucide-react";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { api } from "../lib/api";

export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");

    const form = new FormData(event.currentTarget);
    try {
      const payload =
        mode === "signup"
          ? await api.signup({
              email: String(form.get("email")),
              password: String(form.get("password")),
              organizationName: String(form.get("organizationName"))
            })
          : await api.login({ email: String(form.get("email")), password: String(form.get("password")) });

      window.localStorage.setItem("token", payload.token);
      router.push("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="main">
      <section className="panel" style={{ maxWidth: 460, margin: "7vh auto" }}>
        <div className="section-title">
          <div>
            <div className="brand" style={{ marginBottom: 18 }}>
              <span className="brand-mark">
                <Scale size={18} />
              </span>
              CounselDesk
            </div>
            <h1>{mode === "signup" ? "Create account" : "Welcome back"}</h1>
            <p className="muted">AI-generated insights, not legal advice.</p>
          </div>
        </div>
        <form className="form" onSubmit={submit}>
          {mode === "signup" && (
            <label className="field">
              Organization
              <input name="organizationName" required minLength={2} placeholder="Acme Legal Ops" />
            </label>
          )}
          <label className="field">
            Email
            <input name="email" required type="email" placeholder="you@company.com" />
          </label>
          <label className="field">
            Password
            <input name="password" required type="password" minLength={8} placeholder="At least 8 characters" />
          </label>
          {error && <p className="muted">{error}</p>}
          <button className="button primary" type="submit" disabled={loading}>
            {loading ? "Working..." : mode === "signup" ? "Sign up" : "Log in"}
          </button>
          <a className="button subtle" href={mode === "signup" ? "/login" : "/signup"}>
            {mode === "signup" ? "Already have an account" : "Create a team account"}
          </a>
        </form>
      </section>
    </main>
  );
}
