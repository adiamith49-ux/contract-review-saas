"use client";

import { ArrowRight, FileText, RefreshCw } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AppShell } from "../components/AppShell";
import { UploadPanel } from "../components/UploadPanel";
import { api, ContractListItem, getToken } from "../lib/api";

export default function DashboardPage() {
  const router = useRouter();
  const [contracts, setContracts] = useState<ContractListItem[]>([]);
  const [org, setOrg] = useState<{ name: string; plan: string } | null>(null);
  const [activity, setActivity] = useState<Array<{ id: string; action: string; created_at: string }>>([]);
  const [error, setError] = useState("");

  async function load() {
    try {
      const [profile, list] = await Promise.all([api.me(), api.contracts()]);
      setOrg(profile.organization);
      setActivity(profile.activity);
      setContracts(list.contracts);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load dashboard");
    }
  }

  useEffect(() => {
    if (!getToken()) {
      router.push("/login");
      return;
    }
    void load();
  }, [router]);

  return (
    <AppShell>
      <div className="section-title">
        <div>
          <h1>{org ? org.name : "Contract Review"}</h1>
          <p className="muted">Plan: {org?.plan ?? "loading"} | AI-generated insights, not legal advice.</p>
        </div>
        <button className="icon-button" aria-label="Refresh" title="Refresh" onClick={() => void load()}>
          <RefreshCw size={18} />
        </button>
      </div>
      {error && <p className="muted">{error}</p>}
      <div className="grid two">
        <div className="stack">
          <section className="panel">
            <div className="section-title">
              <div>
                <h2>Past Analyses</h2>
                <p className="muted">Risk level, status, and analysis history.</p>
              </div>
              <FileText size={22} />
            </div>
            <div className="contracts">
              {contracts.map((contract) => (
                <article className="contract-card" key={contract.id}>
                  <div>
                    <strong>{contract.filename}</strong>
                    <p className="muted">{contract.type.replace("_", " ")} | {contract.status}</p>
                  </div>
                  {contract.analysis_id ? (
                    <Link className="button" href={`/analysis/${contract.analysis_id}`}>
                      Open <ArrowRight size={16} />
                    </Link>
                  ) : (
                    <span className={`badge ${contract.risk_level ?? ""}`}>{contract.risk_level ?? "pending"}</span>
                  )}
                </article>
              ))}
              {contracts.length === 0 && <p className="muted">No contracts uploaded yet.</p>}
            </div>
          </section>
          <section className="panel">
            <div className="section-title">
              <h2>Team Activity</h2>
            </div>
            <div className="stack">
              {activity.map((item) => (
                <p className="muted" key={item.id}>
                  {item.action} | {new Date(item.created_at).toLocaleString()}
                </p>
              ))}
              {activity.length === 0 && <p className="muted">Activity will appear here.</p>}
            </div>
          </section>
        </div>
        <UploadPanel onUploaded={() => void load()} />
      </div>
    </AppShell>
  );
}
