import { Router } from "express";
import Stripe from "stripe";
import { z } from "zod";
import { config } from "../config.js";
import { query } from "../db.js";
import { requireAdmin, requireAuth } from "../middleware/auth.js";

export const billingRouter = Router();
const stripe = config.STRIPE_SECRET_KEY ? new Stripe(config.STRIPE_SECRET_KEY) : null;

billingRouter.post("/billing/checkout", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    if (!stripe) {
      return res.status(501).json({ error: "Stripe is not configured" });
    }

    const { plan } = z.object({ plan: z.enum(["pro", "team"]) }).parse(req.body);
    const price = plan === "pro" ? config.STRIPE_PRO_PRICE_ID : config.STRIPE_TEAM_PRICE_ID;
    if (!price) {
      return res.status(500).json({ error: `${plan} price ID is not configured` });
    }

    const org = await query<{ id: string; name: string; stripe_customer_id: string | null }>(
      "SELECT id, name, stripe_customer_id FROM organizations WHERE id = $1",
      [req.user?.orgId]
    );
    let customerId = org.rows[0]?.stripe_customer_id;

    if (!customerId) {
      const customer = await stripe.customers.create({ name: org.rows[0].name, metadata: { orgId: req.user!.orgId } });
      customerId = customer.id;
      await query("UPDATE organizations SET stripe_customer_id = $1 WHERE id = $2", [customerId, req.user?.orgId]);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price, quantity: 1 }],
      success_url: `${config.WEB_URL}/billing?success=true`,
      cancel_url: `${config.WEB_URL}/billing?canceled=true`,
      metadata: { orgId: req.user!.orgId, plan }
    });

    return res.json({ url: session.url });
  } catch (error) {
    return next(error);
  }
});

billingRouter.post("/billing/portal", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    if (!stripe) {
      return res.status(501).json({ error: "Stripe is not configured" });
    }

    const org = await query<{ stripe_customer_id: string | null }>("SELECT stripe_customer_id FROM organizations WHERE id = $1", [req.user?.orgId]);
    if (!org.rows[0]?.stripe_customer_id) {
      return res.status(400).json({ error: "No Stripe customer exists yet" });
    }

    const portal = await stripe.billingPortal.sessions.create({
      customer: org.rows[0].stripe_customer_id,
      return_url: `${config.WEB_URL}/billing`
    });
    return res.json({ url: portal.url });
  } catch (error) {
    return next(error);
  }
});

billingRouter.post("/billing/webhook", async (req, res, next) => {
  try {
    if (!stripe || !config.STRIPE_WEBHOOK_SECRET) {
      return res.status(501).json({ error: "Stripe webhook is not configured" });
    }

    const signature = req.header("stripe-signature");
    if (!signature) {
      return res.status(400).json({ error: "Missing Stripe signature" });
    }

    const event = stripe.webhooks.constructEvent(req.body, signature, config.STRIPE_WEBHOOK_SECRET);
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const orgId = session.metadata?.orgId;
      const plan = session.metadata?.plan;
      if (orgId && (plan === "pro" || plan === "team")) {
        await query("UPDATE organizations SET plan = $1, stripe_subscription_id = $2, updated_at = now() WHERE id = $3", [
          plan,
          typeof session.subscription === "string" ? session.subscription : null,
          orgId
        ]);
      }
    }

    return res.json({ received: true });
  } catch (error) {
    return next(error);
  }
});
