import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { pool } from "../db.js";

const schemaPath = resolve(process.cwd(), "../../packages/database/schema.sql");
const sql = await readFile(schemaPath, "utf8");

await pool.query(sql);
await pool.end();

console.log("Database schema applied");
